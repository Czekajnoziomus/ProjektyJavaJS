uwu = open("punktyo.txt")
# Bo wszystkie kart są wpisane w dokument tekstowy tak jak w przykładach
finallScore = []
def licz(finallScore, punkty):
    for i in punkty:
        score = 0
        all = i.strip()
        for j in all:
            if j == 'T' or j =='J' or j =='Q' or j =='K':
                score += 10
            elif j == 'A':
                score += 11
            else:
                score += int(j)
        if score >= 22:
            score = check(score, all)
        finallScore.append(score)
def check(score, word):
    for i in word:
        single = i.strip()
        if score <=21:
            single=""
        if single == 'A':
            score -= 10
    return score
def winner(ojakata):
    wscore = 0
    wp = 0
    wplayer = []
    for i in ojakata:
        wp+=1
        if i <= 21 and i >= wscore:
            wscore = i
            wplayer.clear()
            wplayer.append(wp)
    print(wplayer)
    print(wscore)
licz(finallScore, uwu)
winner(finallScore)
print(finallScore)