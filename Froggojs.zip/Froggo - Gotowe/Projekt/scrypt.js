$(document).ready(function(){
    $('#hideshow').click(function(){
        $('#content').toggleClass('active');
        $('#content').toggleClass('togle');
    })
})